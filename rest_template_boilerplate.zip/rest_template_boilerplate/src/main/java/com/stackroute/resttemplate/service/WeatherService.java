package com.stackroute.resttemplate.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.stackroute.resttemplate.model.Weather;

@Service
public class WeatherService {

    //add your api key here
    private static final String API_KEY = "102feaa6739a4e5a9ff183359232711";

    //add the base api url here
    private static final String API_URL = "http://api.weatherapi.com/v1/current.json?key=102feaa6739a4e5a9ff183359232711&q=";
//  http://api.weatherapi.com/v1/current.json?key=102feaa6739a4e5a9ff183359232711&q=London&aqi=no
    private final RestTemplate restTemplate;
    public WeatherService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    

    //using rest template, get the weather details of a city
    public Weather getWeather(String city) {
    	
    String url=API_URL + city + "&apiKey=" +  API_KEY ;
    
    ResponseEntity<Weather> forObject = restTemplate.getForEntity(url, Weather.class);
                               Weather body = forObject.getBody();
                                 
        return body;
        
                            
    }


}
