package com.stackroute.resttemplate.model;

public class Current {
    private String temp_c;

    public String getTemp_c() {
        return temp_c;
    }

    public void setTemp_c(String temp_c) {
        this.temp_c = temp_c;
    }
}
